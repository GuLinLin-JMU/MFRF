#'
#' @title Simulated Genome Relationship Matrix.
#'
#'
sim_G <- function(N, k, fam_size=6){
  if( N != abs(round( N )) )
    stop( 'N must be a positive integer' )
  if( fam_size != abs(round( fam_size )) )
    stop( 'fam_size must be a positive integer' )
  num_fams  <- N / fam_size
  if( num_fams != round( num_fams ) )
    stop( 'fam_size must divide N' )
  G   <- matrix(0, N, N )
  for( family in 1:num_fams ){
    fam_inds    <- (family-1)*fam_size + 1:fam_size
    G[ fam_inds, fam_inds ] <- k
  }
  diag(G) <- 1
  return(G)
}
