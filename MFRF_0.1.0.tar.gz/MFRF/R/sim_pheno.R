#'
#' @title Simulated phenotype.
#'
#'
sim_pheno <- function(N, P, K, h2=rep(0.5, P), B, E){
  if( ! all( dim(K) == N ) )
    stop( 'K must be a NxN matrix' )
  if( missing(B) ){
    B <- rWishart( 1, P, 1/P*diag(P) )[,,1]
  } else {
    if( ! all( dim(B) == P ) )
      stop( 'B must be a PxP matrix' )
  }
  if( missing(E) ){
    E <- rWishart( 1, P, 1/P*diag(P) )[,,1]
  } else {
    if( ! all( dim(E) == P ) )
      stop( 'E must be a PxP matrix' )
  }
  B <- diag(sqrt(h2)  ) %*% cov2cor(B) %*% diag(sqrt(h2)  )
  E <- diag(sqrt(1-h2)) %*% cov2cor(E) %*% diag(sqrt(1-h2))
  Y <- mat.sqrt(K) %*% matrix( rnorm(N*P), N, P ) %*% mat.sqrt(B) + matrix( rnorm(N*P), N, P ) %*% mat.sqrt(E)
  return(Y)
}
