#' @title R Package Batch Installation.
#' @description The function is batch installation dependence R packages.
#'
#'
ipak <- function(pkg){
  new.pkg <- pkg[!(pkg %in% installed.packages()[, "Package"])]
  if (length(new.pkg))
    install.packages(new.pkg, dependencies = TRUE)
  sapply(pkg, require, character.only = TRUE)
}
#'
#'
#' @title Welcome to MFRF.
#' @description Just the welcome function that will appear every time that your run the program.
#'
#'
MFRF.version <-function()
{
  message(paste("#", paste(rep("-", 31), collapse=""), "Welcome to MFRF", paste(rep("-", 31), collapse=""), "#", sep=""), "")
  cat("#          _\\\\|//_                                                            #\n")
  cat("#         (^ o-o ^)                                                           #\n")
  cat("#========ooO-(_)-Ooo==========================================================#\n")
  cat("#                    Efficient and accurate phenotype imputation in millions  #\n")
  cat("#                          of individuals for increasing GWAS power.          #\n")
  cat("#                                  linlin-gu@outlook.com                      #\n")
  cat("#       .oooO    Oooo.              fangming618@126.com                       #\n")
  cat("#       (   )    (   )                  November,2022                         #\n")
  cat("#========\\ (======) /===================Version: 0.1.0========================#\n")
  cat("#         \\_)    (_/                                                          #\n")
  message("#-----------------------------------------------------------------------------#\n")
}
#' @title MFRF evaluation indicator.
#' @description The function is the correlation between these imputed phenotypes and their true hidden values.
#‘
#' @param ximp (imputed) matrix
#' @param xmis matrix with missing values
#' @param xtrue true matrix (or any matrix to be compared with ximp)
#'
#'
MFRF.Eval <- function(ximp, xmis, xtrue){
  mis <- is.na(xmis)
  cor(ximp[mis], xtrue[mis])
}
