#' @title Efficient and accurate phenotype imputation in millions of individuals for increasing GWAS power.
#' @description This function impute a large number of phenotypes using the MFRF.
#'
#' @export
#'
#' @examples
#' not run
#'
#' library("MFRF")
#' data(ukb)
#' MFRF.imp <- MFRF(ukb, Total_maxiter = 20, maxiter = 20, num.trees = 100, mtry = floor(sqrt(ncol(ukb))),
#'                  initialLinearEffects = 0, ErrorTolerance = 0.001, targetID = 7, missing_size = 500, seed = 123,
#'  				        replace = TRUE, decreasing = TRUE, verbose = TRUE, sampsize = NULL, max.depth = NULL, xtrue = NA)
#' MFRF.imp$score
#' MFRF.imp$value
#' MFRF.imp$ximp
#' MFRF.imp$bias
#'
MFRF <- function(xmis, Total_maxiter = 20, maxiter = 20, num.trees = 100, mtry = floor(sqrt(ncol(xmis))),
                 initialLinearEffects = 0, ErrorTolerance = 0.001, targetID = NULL, missing_size = 500,
				         seed = 123, replace = TRUE, decreasing = TRUE,verbose = TRUE, sampsize = NULL,
				         max.depth = NULL, xtrue = NA)
{ #' ----------------------------------------------------------------------
  options(warn = 0)
  MFRF.version()
  requireNamespace("ranger")
  require(ranger)
  #' INITIAL CHECKS
  stopifnot(is.data.frame(xmis), dim(xmis) >= 1L, is.numeric(maxiter),
            is.numeric(num.trees), length(maxiter) == 1L,
			maxiter >= 1L)
  #'
  n <- nrow(xmis)
  p <- ncol(xmis)
  rawdata <- xmis
  if (!is.null(targetID)){
    list <- which(!is.na(xmis[,targetID]))
    mis <- sample(list, size = missing_size, replace = FALSE)
    xmis[mis,targetID] <- NA
  }

  #' remove completely missing variables
  if (any(apply(is.na(xmis), 2, sum) == n)){
    indCmis <- which(apply(is.na(xmis), 2, sum) == n)
    xmis <- xmis[,-indCmis]
    p <- ncol(xmis)
    cat('  removed variable(s)', indCmis, 'Due to the missingness of all entries\n')
  }
  #' Initial imputation
  ximp <- imputeUnivariate(xmis)
  #'ximp <- xmis
  #'for (t.co in 1:ncol(xmis)) {
  #'    ximp[is.na(xmis[,t.co]),t.co] <- mean(xmis[,t.co], na.rm = TRUE)
  #'    next()
  #'}
  #'
  #' extract missingness pattern
  NAloc <- is.na(xmis)            # where are missings
  noNAvar <- apply(NAloc, 2, sum) # how many are missing in the vars
  sort.j <- order(noNAvar)        # indices of increasing amount of NA in vars
  if (decreasing)
    sort.j <- rev(sort.j)
  sort.noNAvar <- noNAvar[sort.j]
  #'
  #' output
  Ximp <- vector('list', maxiter)
  #'
  #' initialize parameters of interest
  iter <- 0
  convNew <- 0
  convOld <- Inf
  names(convNew) <- c('numeric')
  convergence <- c()
  #'
  #' function to yield the stopping criterion in the following 'while' loop
  stopCriterion <- function(convNew, convOld, iter, Total_maxiter){
    (convNew < convOld) & (iter < Total_maxiter)
  }
  #'
  #' iterate MFRF
  while (stopCriterion(convNew, convOld, iter, Total_maxiter)){
    if (iter != 0){
      convOld <- convNew
    }
    cat("MFRF iteration", iter+1, "in progress:", sep = " ")
    t.start <- proc.time()
    ximp.old <- ximp
    for (s in 1:p) {
      varInd <- sort.j[s]
      if (noNAvar[[varInd]] != 0) {
        obsi <- !NAloc[, varInd]
        misi <- NAloc[, varInd]
        obsY <- ximp[obsi, varInd]
        obsX <- ximp[obsi, seq(1, p)[-varInd]]
        misX <- ximp[misi, seq(1, p)[-varInd]]
        #'
        Target = obsY
        #' Condition that indicates the loop has not converged or run out of iterations
        ContinueCondition = TRUE
        iterations <- 0
        #'
        #' Get initial values
        #'
		    AdjustedTarget <- Target - initialLinearEffects
        oldLogLik <- -Inf
        while(ContinueCondition){
          iterations <- iterations+1
          FRF <- ranger(x = obsX,
                        y = AdjustedTarget,
                        num.trees = num.trees,
                        mtry = mtry,
						            max.depth = max.depth,
                        replace = TRUE,
                        splitrule =  "variance",
						            write.forest = TRUE,
						            min.node.size=5,
						            oob.error=TRUE,
						            seed = seed)
          #' y - u (out-of-bag prediction)
          resi = Target - FRF$predictions
		      #' Estimate new linear effects and errors using glm
          new_data <- data.frame(resi, obsX)
          n_cov <- ncol(new_data)
          xnam <- paste(colnames(new_data)[2:n_cov] ,sep="", collapse="+")
          fmla <- as.formula(paste("resi ~ -1+", paste(xnam, collapse= "+"))  )
          glmfit <- glm(formula=fmla, data=new_data)
          #'
		      #' check convergence
          newLogLik <- as.numeric(logLik(glmfit))
          ContinueCondition <- (abs(newLogLik-oldLogLik) > ErrorTolerance & iterations < maxiter)
          oldLogLik <- newLogLik
		      #' Extract linear effects to make the new adjusted target
          LinearEffects <- predict(glmfit, obsX)
          #' y-X*b
          AdjustedTarget <- Target - LinearEffects
        }
        Nonlinear_Effects <- predict(FRF, misX)
		    Linear_Effects <- predict(glmfit, misX)
		    misY <-  Nonlinear_Effects$predictions + Linear_Effects
		    ximp[misi, varInd] <- misY
      }
		cat(".")
    }
    cat("\nIteration", iter+1, "completed\n")
    iter <- iter + 1
    Ximp[[iter]] <- ximp
    #'
    #' check the difference between iteration steps
    convNew <- sum((ximp-ximp.old)^2)/sum(ximp^2)
    if (any(!is.na(xtrue))){
      err <- suppressWarnings(MFRF.Eval(ximp, xmis, xtrue))
    }
    #' return status output, if desired
    if (verbose){
      delta.start <- proc.time() - t.start
      if (any(!is.na(xtrue))){
        cat("error(s):", err, "\n")
      }
      cat("ConvNew difference(s):", convNew, "\n")
      cat("       Time consuming:", delta.start[3],"seconds\n\n")
    }
  }
  #'
  #' --------------------------------------------------
  #' produce output w.r.t. stopping rule
  if (iter == maxiter){
    if (any(is.na(xtrue))){
      out <- list(ximp = Ximp[[iter]])
    } else {
      out <- list(ximp = Ximp[[iter]], error = err)
    }
  } else {
    if (any(is.na(xtrue))){
      out <- list(ximp = Ximp[[iter - 1]])
    } else {
      out <- list(ximp = Ximp[[iter - 1]],
                  error = suppressWarnings(MPF.Eval(Ximp[[iter - 1]], xmis, xtrue)))
    }
  }
  if (!is.null(targetID)){
    out$score <- cor(out$ximp[mis,targetID], rawdata[mis,targetID])
    out$value <- as.data.frame(cbind(rawdata[mis,targetID],out$ximp[mis,targetID]))
    names(out$value) <- c("Observed","Imputed")
    fit <- lm(out$value$Imputed~out$value$Observed)
    out$bias <- as.numeric(fit$coefficients[1])
    out$ximp[mis,targetID] <- rawdata[mis,targetID]
  }else{
    out$score <- NA
    out$value <- NA
    out$bias <- NA
  }
  class(out) <- 'MFRF'
  return(out)
}
