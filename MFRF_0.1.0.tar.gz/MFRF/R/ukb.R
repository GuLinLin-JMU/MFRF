#' @name ukb
#' @title Run a examples for an in-development function.
#' @description
#' @item ukb: The real phenotype value for ukb dataset.
#'
#' @docType data
#' @usage data(ukb)
NULL
