#' @title Adds Missing Values to a Vector, Matrix or Data Frame.
#' @description Takes a vector, matrix or data frame and replaces some values by NA.
#'
#' @param x A vector, matrix or data frame.
#' @param noNA Proportion of missing values to add to x. In case x is a data frame, 
#'             noNA can also be a vector of probabilities per column or a named vector (see examples).
#' @param seed An integer seed.
#'
#' @return x with missing values.
#' @export
#'
prodNA <- function(x, noNA = 0.1, seed = NULL){
  stopifnot(noNA >= 0, noNA <= 1, is.atomic(x) || is.data.frame(x))
  if (!is.null(seed)) {
    set.seed(seed)  
  }
  prodNaVec <- function(z, noNA) {
    n <- length(z)
    z[sample(n, round(noNA * n))] <- NA
    return(z)
  }
  # vector or matrix
  if (is.atomic(x)) {
    return(prodNaVec(x, noNA))
  } 
  # data frame
  v <- if (is.null(names(noNA))) names(x) else intersect(names(noNA), names(x))
  x[, v] <- Map(prodNaVec, x[, v, drop = FALSE], noNA)
  return(x)
}
